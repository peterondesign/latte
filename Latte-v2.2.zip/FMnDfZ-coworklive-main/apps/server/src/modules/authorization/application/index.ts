export * from './authorization.application.module'
