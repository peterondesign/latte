

import { CoWorkingSpace } from "../coWorkingSpace"

export class Image {

id: string

url: string

coWorkingSpaceId: string

coWorkingSpace?: CoWorkingSpace

dateCreated: string

dateDeleted: string

dateUpdated: string

}
